package com.mayuri.lastfm.ui;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.mayuri.lastfm.ConnectionConnector.HttpConnector;
import com.mayuri.lastfm.MyApplication;
import com.mayuri.lastfm.R;
import com.mayuri.lastfm.adaptor.RecyclerViewAdapter;
import com.mayuri.lastfm.di.component.ApplicationComponent;
import com.mayuri.lastfm.di.component.DaggerApplicationComponent;
import com.mayuri.lastfm.di.component.DaggerMainActivityComponent;
import com.mayuri.lastfm.di.component.MainActivityComponent;
import com.mayuri.lastfm.di.module.ContextModule;
import com.mayuri.lastfm.di.module.MainActivityContextModule;
import com.mayuri.lastfm.di.qualifier.ActivityContext;
import com.mayuri.lastfm.di.qualifier.ApplicationContext;
import com.mayuri.lastfm.network.ApiClient;
import com.mayuri.lastfm.pojo.AlbumModels;
import com.mayuri.lastfm.pojo.Albummatches;
import com.mayuri.lastfm.pojo.Image;
import com.mayuri.lastfm.pojo.Lastfm;
import com.mayuri.lastfm.pojo.Results;
import com.mayuri.lastfm.retrofit.APIInterface;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity implements RecyclerViewAdapter.ClickListener {

    private RecyclerView recyclerView;
    MainActivityComponent mainActivityComponent;

    @Inject
    public RecyclerViewAdapter recyclerViewAdapter;

    @Inject
    public APIInterface apiInterface;

    @Inject
    @ApplicationContext
    public Context mContext;

    @Inject
    @ActivityContext
    public Context activityContext;

    private List<Lastfm> allData;
    private ArrayList<AlbumModels> albumModels;
    private String requestUrl, searchTxt;
    private EditText edtxtAlbumName;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final Button search = findViewById(R.id.buttonSearch);
        recyclerView = findViewById(R.id.recyclerview);
        recyclerView.setLayoutManager(new LinearLayoutManager(MainActivity.this));
        edtxtAlbumName = findViewById(R.id.edtxtAlbumName);

        //  final SharedPreferences.Editor editor = getSharedPreferences(USER_INPUT, MODE_PRIVATE).edit();


        ApplicationComponent applicationComponent = DaggerApplicationComponent.builder().contextModule(new ContextModule(this)).build();
        applicationComponent.injectApplication(MyApplication.getInstance());

        ApplicationComponent applicationComponent1 = MyApplication.getInstance().getApplicationComponent();
        mainActivityComponent = DaggerMainActivityComponent.builder()
                .mainActivityContextModule(new MainActivityContextModule(this))
                .applicationComponent(applicationComponent)
                .build();

        mainActivityComponent.injectMainActivity(this);

        recyclerViewAdapter = new RecyclerViewAdapter(this);
        recyclerView.setAdapter(recyclerViewAdapter);


        search.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                searchTxt = edtxtAlbumName.getText().toString().trim();

                if (searchTxt != null && searchTxt.length() > 0) {
                    new InitialSetData().execute();
                }
                //String API_KEY = "00b49401c799a92996db257a81aaa3a7";

                /*@GET ("?method=album.search&{album}=&api_key=00b49401c799a92996db257a81aaa3a7&format=json")
                Call<Lastfm> getLastfm(@Query("method") String method, @Query("album") String album, @Query("api_key") String api_key,@Query("format") String format);
*/
//                apiInterface.getLastfm().enqueue(new Callback<Lastfm>() {
//
//                    @Override
//                    public void onResponse(Call<Lastfm> call, Response<Lastfm> response) {
//                        populateRecyclerView(response.body());
//                    }
//
//                    private void populateRecyclerView(Lastfm results) {
//                        recyclerViewAdapter.setData(results);
//                    }
//
//                    @Override
//                    public void onFailure(Call<Lastfm> call, Throwable t) {
//
//                    }
//                });

            }
        });


    }


    private class InitialSetData extends AsyncTask<String, Void, String> {
        private ProgressDialog dialog;

        @Override
        protected String doInBackground(String... params) {
            /* Get Initial value from locally json data */
            try {
                requestUrl = ApiClient.BASE_URL + "?method=album.search&album=" + searchTxt + "&api_key=00b49401c799a92996db257a81aaa3a7&format=json";
                albumModels = new ArrayList<>();
                new HttpConnector(requestUrl);
                String jsonobjStr = HttpConnector.fetchData(getApplicationContext());
                JSONObject obj = new JSONObject(jsonobjStr);
                JSONObject results = obj.optJSONObject("results");
                JSONObject albummatches = results.optJSONObject("albummatches");
                JSONArray album = albummatches.optJSONArray("album");
                if (album != null && album.length() > 0) {
                    for (int i = 0; i < album.length(); i++) {
                        AlbumModels albumModels1 = new AlbumModels();
                        JSONObject childData = album.getJSONObject(i);
                        albumModels1.setName(childData.optString("name"));
                        albumModels1.setArtist(childData.optString("artist"));
                        albumModels1.setUrl(childData.optString("url"));
                        ArrayList<Image> allImages = new ArrayList<>();
                        try {
                            JSONArray jsonArrayImage = childData.optJSONArray("image");
                            if (jsonArrayImage != null && jsonArrayImage.length() > 0) {
                                for (int j = 0; j < jsonArrayImage.length(); j++) {
                                    Image image = new Image();

                                    JSONObject allImageSize = jsonArrayImage.getJSONObject(j);
                                    image.setSize(allImageSize.optString("size"));
                                    image.setText(allImageSize.optString("#text"));
                                    allImages.add(image);
                                }

                            }
                        } catch (Exception ex) {

                        }
                        albumModels1.setImage(allImages);
                        albumModels.add(albumModels1);
                    }
                }


            } catch (Exception ex) {

            }
            return null;
        }

        @Override
        protected void onPostExecute(String result) {

            if (albumModels != null && albumModels.size() > 0) {
                Log.e("EM", "::::::::::::Size:::::::::" + albumModels.size());
                recyclerViewAdapter.setData(albumModels, MainActivity.this);
            }
            if (dialog.isShowing()) {
                dialog.dismiss();
            }
        }

        @Override
        protected void onPreExecute() {
            dialog = new ProgressDialog(MainActivity.this);
            dialog.setMessage("Please wait..");
            dialog.show();
        }

        @Override
        protected void onProgressUpdate(Void... values) {
        }
    }


    @Override
    public void launchIntent(String filmName) {

    }
}
