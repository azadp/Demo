package com.mayuri.lastfm.network;

public class ApiClient {

    public static String BASE_URL = "http://ws.audioscrobbler.com/2.0/";


}
